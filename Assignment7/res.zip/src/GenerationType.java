/**
 * Enumerated type to use when generating a certain type of image.
 */
public enum GenerationType {
  HOR_RAINBOW_STRIPES, VERT_RAINBOW_STRIPES, CHECKERBOARD, FLAG
}
