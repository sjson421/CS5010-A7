/**
 * Enumerated type for the names of flag countries.
 */
public enum FlagType {
  FRANCE, GREECE, SWITZERLAND
}
